#!/bin/bash

targetWS=$1

# Get current monitor name
currentMonitor=$(hyprctl monitors -j | jq -r '.[] | select(.focused==true).name')

# Define your monitor names (adjust to your system)
MON1="DP-1"
MON2="HDMI-A-1"

# Determine actual workspace number based on monitor
# On MON1 → 1–10
# On MON2 → 11–20
if [[ "$currentMonitor" == "$MON1" ]]; then
    actualWS=$targetWS
elif [[ "$currentMonitor" == "$MON2" ]]; then
    actualWS=$((targetWS + 10))
else
    # Unknown monitor, do nothing
    exit 0
fi

# Switch to that workspace
hyprctl dispatch workspace "$actualWS"

